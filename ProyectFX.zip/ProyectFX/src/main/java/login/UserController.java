package login;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

import java.net.URL;
import java.util.ResourceBundle;

public class UserController implements Initializable {

    @FXML
    private TextField txtName;

    @FXML
    private TextField txtEmail;

    @FXML
    private Button btnSave;

    @FXML
    private Label lblStatus;

    public UserController(Login login) {

    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {

        btnSave.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
                String name = txtName.getText();
                String email = txtEmail.getText();

                // TODO: Save user data to database or file

                lblStatus.setText("User data saved successfully.");
            }
        });
    }
}
