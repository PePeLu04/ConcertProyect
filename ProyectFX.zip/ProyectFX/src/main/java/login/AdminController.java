package login;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.layout.AnchorPane;

import java.net.URL;
import java.util.ResourceBundle;

public class AdminController implements Initializable {

    @FXML
    private Button btnChangeColor;

    @FXML
    private AnchorPane anchorPane;

    public AdminController(Login login) {

    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {

        btnChangeColor.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
                anchorPane.setStyle("-fx-background-color: #f4f4f4");
            }
        });
    }
}
